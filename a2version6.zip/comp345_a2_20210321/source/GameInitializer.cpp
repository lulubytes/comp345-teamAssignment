#include "..\header\GameInitializer.h"
#include <filesystem>




namespace fs = std::experimental::filesystem;
GameInitializer::GameInitializer() {

	this->map = nullptr;
	this->mapLoader = nullptr;
	for (vector<Player*> ::iterator it = this->players.begin(); it != this->players.end(); it++) {
		*it = NULL;
	}

}


GameInitializer::~GameInitializer() {
	if (this->mapLoader != NULL) {
		delete mapLoader;
		mapLoader = NULL;
	}
	if (this->map != NULL) {
		delete map;
		map = NULL;
	}
	for (vector<Player*>::iterator it = this->players.begin(); it != this->players.end(); it++) {
		delete *it;
		*it = NULL;
	}

}

void GameInitializer::game_Show() {
	cout << "*************************************************************" << endl;
	cout << "**************                            *******************" << endl;
	cout << "**************   Eight-Minutes Empire     *******************" << endl;
	cout << "**************                            *******************" << endl;
	cout << "*************************************************************" << endl;

}

void GameInitializer::show_Menu() {
	cout << "*************************************************************************" << endl;
	cout << "***********   WELCOME TO THE EIGHT-MINUTE EMPIRE GAME  ******************" << endl;
	cout << "**************       1. CHOSE MAP                    ********************" << endl;
	cout << "**************       2. START PLAY THE GAME         *********************" << endl;
	cout << "**************       3. EXIT THE GAME               *********************" << endl;
	cout << "*************************************************************************" << endl;
	cout << "*************************************************************************" << endl;
	cout << endl;

}

Map* GameInitializer::choose_Map() {
	Map* m1 = new Map();
	int choice;
	string fileName;
	cout << "What's kind of map you would like to play? \n1 -- Rectangular Shap\n2 -- L Shape\n3 -- Invalid Map" << endl;
	cin >> choice;
	while (true) {
		if (choice == 1) {
			cout << "reading Rectangular Shape map from mapFiles\\map5.json" << endl;
			fileName = "mapFiles\\map5.json";
			system("pause");
			system("cls");

			this->game_Show();
			// IF LOAD FALID ==> STOP SYSTEM !!!
			this->loadMap(fileName);

			// LOAD SUCCESSFULLY
			this->getCurrentMap()->validate();

			//// IF MAP INVALID ==> STOP SYSTEM !!!
			//if (this->getCurrentMap()->validate==false) {
			//	cout << "Map is not ValidateMap" << endl;
			//	system("pause");
			//	exit(0);
			//}

			// VALIDATE MAP

			m1 = this->getCurrentMap();
			system("pause");
			system("cls");

			this->game_Show();
			cout << *m1;
			system("pause");
			system("cls");

			this->game_Show();
			this->printMapInRectangleShape(m1);
			system("pause");
			system("cls");

			break;

		}
		else if (choice == 2) {
			cout << "reading L Shape map from mapFiles\\map6.json" << endl;
			fileName = "mapFiles\\map6.json";
			system("pause");
			system("cls");

			this->game_Show();
			// IF LOAD FALID ==> STOP SYSTEM !!!
			this->loadMap(fileName);

			// LOAD SUCCESSFULLY
			this->getCurrentMap()->validate();

			//// IF MAP INVALID ==> STOP SYSTEM !!!
			//if (this->getCurrentMap()->validate==false) {
			//	cout << "Map is not ValidateMap" << endl;
			//	system("pause");
			//	exit(0);
			//}

			// VALIDATE MAP

			m1 = this->getCurrentMap();
			system("pause");
			system("cls");


			this->game_Show();
			cout << *m1;
			system("pause");
			system("cls");

			this->game_Show();
			this->printMapInLShape(m1);
			system("pause");
			system("cls");

			break;
		}
		else if (choice == 3) {
			cout << "reading Invalid map from mapFiles\\map3.json" << endl;
			fileName = "mapFiles\\map3.json";
			//system("cls");

			// IF LOAD FALID ==> STOP SYSTEM !!!
			this->loadMap(fileName);
			system("cls");
			break;
		}
		else {
			cout << "Only 1, 2, 3 are permited! Please try again!\n";
			cout << "Which shape you would like to loded?\n1-- ***Rectangular Shape***\n2-- ***L Shape***\n3 -- Invalid Map" << endl;
			cin >> choice;
		}
	}

	return m1;


}





//initialize the player
vector<Player*>& GameInitializer::choose_Player() {

	int  choice = 0;
	string color1;
	string color2;
	string name1;
	string name2;
	string winner;
	Bidding *b1;
	Bidding *b2;
	vector<Bidding*> vBid;
	vector<Territory*> t1;
	vector<Territory*>t2;

	vector<Card*> c1;
	vector<Card*>c2;

	cout << "How many Player you would like to play with? \n1 -- two PLAYERS\n2 -- three PLAYERS\n3 -- four PLAYERS" << endl;
	cin >> choice;
	while (true) {
		if (choice == 1) {

			system("cls");
			this->game_Show();
			cout << "Please insert first Player's name" << endl;
			cin >> name1;
			while (name1 == "") {
				cout << "Player's name can not be empty, please enter again" << endl;
				cin >> name1;
			}
			cout << "Please choose a color \n*****red*****\n*****yellow*****\n*****blue*****\n*****green*****" << endl;
			cin >> color1;
			while (true) {
				if ((color1 == "red") || (color1 == "yellow") || (color1 == "blue") || (color1 == "green"))
					break;
				else {
					cout << "This color does not exist, please insert the color color!" << endl;
					cin >> color1;
				}
			}

			b1 = new Bidding(name1, 0);
			Player *p1 = new Player(name1, 10, 0, t1, c1, b1, color1);

			p1->getBid()->SetBid();

			cout << "Please insert second Player's name" << endl;
			cin >> name2;
			while (name2 == "" || name2 == name1) {
				if (name2 == "") {
					cout << "Player's name can not be empty, please insert again" << endl;
					cin >> name2;
				}
				else {
					cout << "Player's name can not be the same as the first player, Please insert again." << endl;
					cin >> name2;
				}

			}

			cout << "Please choose a color \n*****red*****\n*****yellow*****\n*****blue*****\n*****green*****" << endl;
			cin >> color2;
			cout << endl;
			while (true) {
				if ((color1 != color2) && (color2 == "red" || color2 == "yellow" || color2 == "blue" || color2 == "green"))
					break;
				else if (color1 == color2) {
					cout << "Color can not be the same as the first player's color, Please choose again!" << endl;
					cin >> color2;
					cout << endl;
				}
				else {
					cout << "This color does not exist, please insert the color color!!" << endl;
					cin >> color2;
					cout << endl;
				}

			}
			b2 = new Bidding(name2, 0);
			Player *p2 = new Player(name2, 10, 0, t1, c1, b2, color2);
			p2->getBid()->SetBid();

			system("pauser");
			system("cls");
			this->game_Show();
			cout << "Players Information:\n\n**First Player**  " << *p1 << "  \n**Second Player**  " << *p2 << "  " << endl;

			this->players.push_back(p1);
			this->players.push_back(p2);

			cout << " ** " << p1->GetName() << " **  and  ** " << p2->GetName() << " ** \n*****welcome to the game , Hope you enjoy the Game!*****\n" << endl;

			vBid.push_back(b1);
			vBid.push_back(b2);
			int winnerIndex;
			winner = Bidding::CompareBid(vBid);
			for (int i = 0; i < players.size(); i++) {
				if (players[i]->GetName() == winner) {
					winnerIndex = i;
				}
			}
			this->assignCoin();
			for (int i = 0; i < players.size(); i++) {
				if (players[i]->GetName() == winner) {
					//winner pay coins
					players[i]->PayCoin(players[i]->getBid()->GetBid());
					//pool receive coins;
					this->pool += players[i]->getBid()->GetBid();

				}
			}


			// set original region for each players
			this->SetInitialRegion(winnerIndex);











			//Part 2 point 1 remove 3 and 4 cards
			cout << "\nWe have " << players.size() <<" of players, so remove the \"4\" and \"3\" cards\n"<< endl;

			//this->deckInitial();
			Deck* deck = new Deck(players.size());//creat the deck 
			
			deck->generateDeck();//generate the deck
			


			cout << "\n*************************Before the Shuffle********************************" << endl;
			cout << *deck;

			deck->shuffleDeck();//shuffle the Deck
			cout << "**********************After the Shuffle**************************************" << endl;
			cout << *deck;


			deck->shuffleDeck();//shuffle the Deck
			cout << "**********************After another Shuffle****************************" << endl;
			cout << *deck;

			/*cout << "************************" << winner << " please chose your original territory" << endl;
			cin >> choice;
			
			for (int i = 0; i < map->GetContinentCount(); i++) {
				for (int j = 0; j < map->continents[i]->getTerritoryCount(); j++) {
					if (choice == map->continents[i]->territorys[j]->GetID()) {
						map->continents[i]->territorys[j]->SetPlayer(winner);
						cout << map->continents[i]->territorys[j]->GetName() << endl;
						
					}
				}
			}

			*/
			
			



			//loop for the game until the end
			Hand* hand = new Hand(deck);//drwa the 6 face-up card from the deck
			while (players[winnerIndex]->GetHandCard().size() <= 4 && players[1-winnerIndex]->GetHandCard().size() <= 4) {
				this->playGame(winnerIndex,hand,deck);
				this->playGame(1-winnerIndex,hand,deck);
			}


			cout << "winner is :          "<<endl;

			system("pause");

			break;
		}
		else if (choice == 2) {

			cout << "We wil not try 3 players game, Only 2 players is allowed for Assignment. Please try again!\n";
			cout << "How many Player you would like to play with? \n1 -- two PLAYERS\n2 -- three PLAYERS\n3 -- four PLAYERS" << endl;
			cin >> choice;

		}
		else if (choice == 3) {

			cout << "We wil not try 4 players game, Only 2 players is allowed for Assignment. Please try again!\n";
			cout << "How many Player you would like to play with? \n1 -- two	PLAYERS\n2 -- three PLAYERS\n3 -- four PLAYERS" << endl;
			cin >> choice;

		}
		else {
			cout << "Invalid Number, please try again, \n1 -- 2	PLAYERS\n2 -- 3 PLAYERS\n3 -- four PLAYERS" << endl;
			cin >> choice;
		}

	}


	return this->players;

}



void GameInitializer::exitSystem() {
	cout << "~~~~~WELCOME BACK NEXT TIME *_* ~~~~~" << endl;
	system("pause");
	exit(0);
}

Map * GameInitializer::getCurrentMap() {
	try {
		return this->map;
	}
	catch (runtime_error) {
		cout << "File is not falid" << endl;
	}
}

vector<string> GameInitializer::getGameMapFiles() {
	vector<string> maps;
	for (const auto & entry : fs::directory_iterator(mapFileFolder)) {
		std::cout << entry.path() << std::endl;
		maps.push_back(entry.path().string());
	}
	return maps;
}

void GameInitializer::loadMap(string mapFileName) {
	this->mapLoader = new MapLoader(mapFileName);
	if (this->mapLoader->readMapFile()) {
		this->map = this->mapLoader->getMap();
	}
	else {
		cout << "MAP INVALID TO LOAD...EXIT PROGRAM NOW\n";
		system("pause");
	}
}



void GameInitializer::addPlayer(string playerName) {
	vector<Card*> cards;
	Bidding* bid = new Bidding();
	Player* player = new Player(playerName, cards, bid);

}

string GameInitializer::getMapFileFolder() {
	return this->mapFileFolder;
}


//Rectangule Shape read from mapFiles\\map5.json
void GameInitializer::printMapInRectangleShape(Map* m1) {

	cout << "Rectuangule shape map Read from mapFiles\\map5.json..." << endl;
	cout << "\n*********************  MAP IN RECTANGULE SHAPE  ***************\n\n";
	for (int i = 0; i < m1->GetContinentCount(); i++) {
		cout << " ~~~" << m1->continents[i]->GetName() << "~~~ " << "    ";

	}
	cout << "***************************************************************************************\n\n" << endl;
	for (int i = 0; i < m1->GetContinentCount(); i++) {
		if (i == 1) cout << " [ *" << m1->continents[i]->territorys[3]->GetName() << "* ] " << "____";
		else if (i == 3) cout << " [ *" << m1->continents[i]->territorys[3]->GetName() << "* ] " << "    ";
		else cout << " [ *" << m1->continents[i]->territorys[0]->GetName() << "* ] " << "    ";

	}
	cout << endl;

	for (int i = 0; i < m1->GetContinentCount(); i++) {
		if (i == 1) cout << " [ *" << m1->continents[i]->territorys[2]->GetName() << "* ] " << "    ";
		else if (i == 3) cout << " [ *" << m1->continents[i]->territorys[2]->GetName() << "* ] " << "    ";
		else cout << " [ *" << m1->continents[i]->territorys[1]->GetName() << "* ] " << "    ";

	}
	cout << endl;

	for (int i = 0; i < m1->GetContinentCount(); i++) {
		if (i == 1) cout << " [ *" << m1->continents[i]->territorys[1]->GetName() << "* ] " << "    ";
		else if (i == 3) cout << " [ *" << m1->continents[i]->territorys[1]->GetName() << "* ] " << "    ";
		else cout << " [ *" << m1->continents[i]->territorys[2]->GetName() << "* ] " << "    ";
	}
	cout << endl;
	cout << "\t|_____________" << " [ *" << m1->continents[1]->territorys[0]->GetName() << "* ] " << "           |_______________";
	cout << "[ *" << m1->continents[3]->territorys[0]->GetName() << "* ] " << "    " << endl;
	cout << "\n\n***************************************************************************************\n\n" << endl;

}

void GameInitializer::printMapInLShape(Map* m1) {
	cout << "L shape map Read from mapFiles\\map6.json..." << endl;
	cout << "\n*********************  MAP IN L SHAPE  ***************\n\n";

	cout << "***************************************************************************************\n\n" << endl;
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < m1->continents[i]->getTerritoryCount(); j++) {
			cout << " [ *" << m1->continents[i]->territorys[j]->GetName() << "* ] " << endl;
		}
		cout << "\t|" << endl;
		cout << "\t|" << endl;
	}
	for (int i = 0; i < 3; i++) {
		cout << " [ *" << m1->continents[2]->territorys[i]->GetName() << "* ] " << "    ";
		cout << " [ *" << m1->continents[3]->territorys[3 - i]->GetName() << "* ] " << "    \n";
	}
	cout << " [ *" << m1->continents[2]->territorys[3]->GetName() << "* ] " << "____";
	cout << " [ *" << m1->continents[3]->territorys[0]->GetName() << "* ] " << "    ";
	cout << "\n\n***************************************************************************************\n\n" << endl;

}



void GameInitializer::deckInitial() {

}


void GameInitializer::assignCoin() {
	int coin = 0;
	if (players.size() == 4)
		coin = 9;
	if (players.size() == 3)
		coin = 11;
	if (players.size() == 2)
		coin = 14;

	for (int i = 0; i < players.size(); i++) {
		players[i]->SetCoin(coin);
	}
}

//loop 
void GameInitializer::playGame(int playerNumber, Hand* hand, Deck* deck) {
	cout <<players[playerNumber]->GetName() << "what index of card do u want, please insert 0-5 please!" << endl;
	int index;
	cin >> index;
	while (index >=6 || index < 0) {
		cout << players[playerNumber]->GetName() << " your index input is invalid, please insert ** 0 - 5** " << endl;
		cin >> index;
	}
	

	players[playerNumber]->SetHandCard(hand->exchange(index));//select the card from the row
	players[playerNumber]->PayCoin(hand->getCost(index));//pay the coin of that card
	this->pool += hand->getCost(index);// put it at the top of the board
	

	//if(players[playerNumber]->GetHandCard()[0]->getAction1()=="Add2")
	cout << "" << players[playerNumber]->GetHandCard()[0]->getAbility();
	cout << "" << players[playerNumber]->GetHandCard()[0]->getAction1();
	cout << "" << players[playerNumber]->GetHandCard()[0]->getAction2();
	cout << "" << players[playerNumber]->GetHandCard()[0]->getGood();

	cout << pool << endl;
	cout << hand->getCost(index);


	cout << "***************************************" << endl;



}









//void GameInitializer::bidPhase() {
//  cout << " now starting the Bidding phase: " << endl;
//  vector<Bidding*> Biddings;
//  for (int i = 0; i < players.size(); i++) {
//   cout << players[i]->GetName() << ": your turn to bid." << endl;
//   players[i]->getBid()->SetBid();
//   Biddings.push_back(players[i]->getBid());
//  }//set the Bid
//  
//  Bidding::CompareBid(Biddings);//Bid the phase,record the winner
//   
//  
// }




void GameInitializer::SetInitialRegion(int winnerIndex) {
	int regionNumber1;
	int regionNumber2;
	vector<Territory*> allTerritories;
	allTerritories = map->GetAllTerritorys();

	


	cout << "Start Initial Region for Players...\n";

	// For first Player==> winner
	cout << "Select the Initial Region for First Player(Winner) ==> " << players[winnerIndex]->GetName() << ": ";
	cin >> regionNumber1;
	for (int i = 0; i < allTerritories.size(); i++) {
		// first one to select, do not need to check if territories occupied 
		if (allTerritories[i]->GetID() == regionNumber1) {
			allTerritories[i]->SetPlayer(players[winnerIndex]->GetName());
			allTerritories[i]->SetArmyNum(allTerritories[i]->GetArmyNum() + 4);
			players[winnerIndex]->setArmy(players[1 - winnerIndex]->getArmy() - 4);
			players[winnerIndex]->setTerritories(allTerritories[i]);
			break;
		}
	}

	// For second Player
	cout << "Select the Initial Region for Second Player ==> " << players[1 - winnerIndex]->GetName() << ": ";
	cin >> regionNumber2;
	// check if region has been occupied
	while (regionNumber2 == regionNumber1) {
		cout << "Region has been occupied!!! Please Seclect Another Region....\n";
		cin >> regionNumber2;
	}
	for (int j = 0; j < allTerritories.size(); j++) {
		if (allTerritories[j]->GetID() == regionNumber2) {
			allTerritories[j]->SetPlayer(players[1 - winnerIndex]->GetName());
			allTerritories[j]->SetArmyNum(allTerritories[j]->GetArmyNum() + 4);


			players[1 - winnerIndex]->setArmy(players[1 - winnerIndex]->getArmy() - 4);
			players[1 - winnerIndex]->setTerritories(allTerritories[j]);
			break;

		}
	}

		

	cout << "Player " << players[winnerIndex]->GetName() << " remains Army : " << players[winnerIndex]->getArmy() << endl;
	
   cout << "Player " << players[1-winnerIndex]->GetName() << " remains Army : " << players[1-winnerIndex]->getArmy() << endl;

   cout << "Player " << players[winnerIndex]->GetName() << "has initial rigion: " << *players[winnerIndex]->GetTerritorys()[0] << endl;
	  
   cout << "Player " << players[1 - winnerIndex]->GetName() << "has initial rigion: " << *players[1-winnerIndex]->GetTerritorys()[0]<< endl;
  
  

   system("pause");


}