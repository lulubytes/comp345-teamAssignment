#include "Map.h"
#include "MapLoader.h"
#include "Player.h"
#include "Cards.h"
#include "Bidding.h"
#include <vector>

using namespace std;

class GameInitializer{

public:
	const string mapFileFolder = "../mapFiles";
	MapLoader* mapLoader;
	Map* map;
	vector<Player*> players;
	int pool;

    GameInitializer();
	~GameInitializer();
	void game_Show();
	void show_Menu();
    vector<string> getGameMapFiles();
	Map* getCurrentMap();
    void loadMap(string mapFileName);
    void addPlayer(string playerName);
    string getMapFileFolder();
	void printMapInRectangleShape(Map*m);
	void printMapInLShape(Map* m);
	Map * choose_Map();
	vector<Player*>& choose_Player();
	void exitSystem();
	void deckInitial();
	void assignCoin();
	//string bidPhase();
	void playGame(int playerNumber, Hand* hand, Deck* deck);

	void SetInitialRegion(int winnerIndex);
	
};
