

class GameMain{
private:

public:
    GameMain();

};