#include "..\header\GameInitializer.h"
#include <filesystem>

namespace fs = std::experimental::filesystem;

GameInitializer::GameInitializer() {
	
	this->map = nullptr;
	this->mapLoader = nullptr;
	for (vector<Player*> ::iterator it = this->players.begin(); it != this->players.end(); it++){
		*it=NULL;
}

}


GameInitializer::~GameInitializer() {
	if (this->mapLoader != NULL) {
		delete mapLoader;
		mapLoader = NULL;
	}
	if (this->map != NULL) {
		delete map;
		map = NULL;
	}
	for (vector<Player*>::iterator it = this->players.begin(); it != this->players.end(); it++) {
		delete *it;
		*it = NULL;
	}
	
}

Map * GameInitializer::getCurrentMap() {
	return this->map;
}

vector<string> GameInitializer::getGameMapFiles(){
    vector<string> maps;
    for (const auto & entry : fs::directory_iterator(mapFileFolder)){
        std::cout << entry.path() << std::endl;
        maps.push_back(entry.path().string());
    }
    return maps;
}

void GameInitializer::loadMap(string mapFileName){
    this->mapLoader=new MapLoader(mapFileName);
    if(this->mapLoader->readMapFile()){
        this->map=this->mapLoader->getMap();
    }else{
        cout<< "Map Invild";
    }
}

void GameInitializer::addPlayer(string playerName){
    vector<Card*> cards;
    Bidding* bid=new Bidding();
    Player* player=new Player(playerName,cards,bid);
    
}

string GameInitializer::getMapFileFolder(){
    return this->mapFileFolder;
}