#include "..\header\GameInitializer.h"

using namespace std;

class GameInitializerDriver
{

public:

	void run()
	{
		GameInitializer *gameInitializer = new GameInitializer();
		cout << "GameInitiazlider started" << endl;

		int choice;
		cout << "Which shape you would like to loded?\n1-- ***Rectangular Shape***\n2-- ***L Shape***" << endl;
		cin >> choice;

		while (!(choice == 1 || choice == 2)) {
			cout << "Only 1 and 2 is permited! Please try again!\n";
			cout << "Which shape you would like to loded?\n1-- ***Rectangular Shape***\n2-- ***L Shape***" << endl;
			cin >> choice;
		}
		switch (choice) {
		case 1:
			cout << "reading map from mapFiles\\map5.json" << endl;
			gameInitializer->loadMap("mapFiles\\map5.json");
			break;

		case 2:
			cout << "reading map from mapFiles\\map1.json" << endl;
			gameInitializer->loadMap("mapFiles\\map1.json");
			break;

		default:
			cout << "Invalid Map, Please try again! " << endl;
			break;
		}

		////
		cout << "reading map from " << gameInitializer->getMapFileFolder() << endl;

		cout << "Read maps" << endl;
		////vector<string> maps = gameInitializer->getGameMapFiles();

		vector<string > maps;
		


		/*for (vector<string>::iterator it = maps.begin(); it != maps.end(); it++) {
			cout << *it << " "<< endl;
		}*/

		///*for (int i = 0; i < maps.size(); i++) {
		//	cout << maps[i] << "  " << endl;
		//}*/
		//cout << "CHOSSE A FILE ABOVE TO PLAY: " << endl;
		//string filename = "";
		//cin >> filename;
		//gameInitializer->loadMap(filename);
		//if (gameInitializer->getCurrentMap() != nullptr) {
		//	gameInitializer->getCurrentMap()->validate();
		//}



		//for (int i = 0; i < maps.size(); i++) {
		//	gameInitializer->loadMap(maps[i]);
		//	/* Map* map = gameInitializer->getCurrentMap();
		//	 cout << map->GetName();
		//	 delete map;*/
		//}
	}
};
