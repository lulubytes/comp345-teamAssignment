#include "..\header\GameObserver.h"
#include<iostream>
//Observer
Observer::~Observer()
{

}

Observer::Observer()
{

}

//Subject
Subject::Subject()
{
	_observers = new list<Observer*>;
}

Subject::~Subject()
{
	for (Observer* observer : *_observers)
	{
		if (observer != nullptr)
		{
			delete observer;
			observer = nullptr;
		}
	}
	delete _observers;
}

void Subject::Attach(Observer* o)
{
	_observers->push_back(o);
}

void Subject::Detach(Observer* o)
{
	_observers->remove(o);
}

void Subject::Notify()
{
	list<Observer*>::iterator i;
	for (i = _observers->begin(); i != _observers->end(); ++i)
	{
		(*i)->Update();
	}
}

//---------------------------------------Phase class
Phase::Phase(Hand* hand, Player* p,int index) {
	this->hand = hand;
	this->p = p;
	cardIndex = index;
}

Phase::~Phase() {

}

string Phase::getPlayerName() {
	return p->GetName();
}

int Phase::getCardIndex() {
	return cardIndex;
}

Card* Phase::showCard() {
	return p->GetHandCard()[p->GetHandCard().size()-1];
}//show the last drawed card 

void Phase::playGmae() {
	//play game here
	Notify();
}
//--------------------------------------------

//--------------------viewer class
Viewer::Viewer() {

}

Viewer::Viewer(Phase* p1) {
	_subject = p1;
	_subject->Attach(this);
}

Viewer::~Viewer() {
	_subject->Detach(this);
}

void Viewer::Update() {
	display();
}

void Viewer::display() {
	string name = _subject->getPlayerName();
	int index = _subject->getCardIndex();
	Card* card = _subject->showCard();//the things get updated
	cout<< "Player : "<<  name <<"'s Phase:\n seleted the card # "<< index << "  From the left." <<endl;
	cout << "The card information is below: " << *card << endl;
}
//-------------------------------------------------

//--------------------Controllor class
Controller::Controller(Phase *p1,Viewer* v1) {
	this->p1 = p1;
	this->v1 = v1;
}

void Controller::controll() {
	p1->playGmae();
}


