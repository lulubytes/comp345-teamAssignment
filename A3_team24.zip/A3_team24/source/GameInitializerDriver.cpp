#include "..\header\GameInitializer.h"

using namespace std;

class GameInitializerDriver
{

public:

	void run()
	{
				
		




		//cout << "GameInitiazlider started" << endl;
		//cout << "reading map from " << gameInitializer->getMapFileFolder() << endl;

		//cout << "Read maps" << endl;
		//vector<string> maps = gameInitializer->getGameMapFiles();

		//cout << "CHOSSE A FILE ABOVE TO PLAY: " << endl;      //  mapFiles\\map6.json
		//string filename = "";
		//cin >> filename;

		//// IF LOAD FALID ==> STOP SYSTEM !!!
		//gameInitializer->loadMap(filename);

		//// LOAD SUCCESSFULLY
		//gameInitializer->getCurrentMap()->validate();

		//// IF MAP INVALID ==> STOP SYSTEM !!!
		//if (gameInitializer->getCurrentMap()->validateMap = false) {
		//	cout << "Map is not ValidateMap" << endl;
		//	system("pause");
		//}
		//	

		//// VALIDATE MAP
		//cout << "\nMAP IS VALID WITH NAME ==>" << gameInitializer->getCurrentMap()->continentCount << endl;
		//vector<Map*> currentMap;
		//Map *m1= gameInitializer->getCurrentMap();
		//cout <<"map count is"<< m1->continentCount << endl;
		//cout << "map territory is" << m1->continents[1]->territorys[1]->GetName();

		//cout << "******************************" << endl;
		//gameInitializer->printMap(m1);
		//gameInitializer->printMapInRectangleShape(m1);
		//







		////for(int i=0;i<maps.size();i++){
		////    gameInitializer->loadMap(maps[i]);	
		////}








	
		
		
		//cout << "CHOSSE A FILE ABOVE TO PLAY: " << endl;
		//string filename = "";
		//cin >> filename;
		//gameInitializer->loadMap(filename);
		//if (gameInitializer->getCurrentMap() != nullptr) {
		//	gameInitializer->getCurrentMap()->validate();
		//}



		/*for (int i = 0; i < maps.size(); i++) {
			gameInitializer->loadMap(maps[i]);
			Map* map1= & gameInitializer->getCurrentMap();
			cout << "**********";
			cout << map1->continentCount << endl;
			
		}

		cout << "********************" << endl;
*/
	}
};
