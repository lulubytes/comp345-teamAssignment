#include "Map.h"
#include "MapLoader.h"
#include "Player.h"
#include "Cards.h"
#include "Bidding.h"
#include <vector>


class GameStartup{
private:

public:
    GameStartup();

	void getInitializeReday();
	
	
};