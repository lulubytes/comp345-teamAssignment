#include "..\header\GameStartup.h"

using namespace std;

GameStartup::GameStartup(){


}

void GameStartup::getInitializeReday() {
	
}
