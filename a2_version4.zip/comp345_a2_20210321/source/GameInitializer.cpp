#include "..\header\GameInitializer.h"
#include <filesystem>




namespace fs = std::experimental::filesystem;
GameInitializer::GameInitializer() {

	this->map = nullptr;
	this->mapLoader = nullptr;
	for (vector<Player*> ::iterator it = this->players.begin(); it != this->players.end(); it++) {
		*it = NULL;
	}

}


GameInitializer::~GameInitializer() {
	if (this->mapLoader != NULL) {
		delete mapLoader;
		mapLoader = NULL;
	}
	if (this->map != NULL) {
		delete map;
		map = NULL;
	}
	for (vector<Player*>::iterator it = this->players.begin(); it != this->players.end(); it++) {
		delete *it;
		*it = NULL;
	}

}

void GameInitializer::game_Show() {
	cout << "*************************************************************" << endl;
	cout << "**************                            *******************" << endl;
	cout << "**************   Eight-Minutes Empire     *******************" << endl;
	cout << "**************                            *******************" << endl;
	cout << "*************************************************************" << endl;

}

void GameInitializer::show_Menu() {
	cout << "*************************************************************************" << endl;
	cout << "***********   WELCOME TO THE EIGHT-MINUTE EMPIRE GAME  ******************" << endl;
	cout << "**************       1. CHOSE MAP                    ********************" << endl;
	cout << "**************       2. START PLAY THE GAME         *********************" << endl;
	cout << "**************       3. EXIT THE GAME               *********************" << endl;
	cout << "*************************************************************************" << endl;
	cout << "*************************************************************************" << endl;
	cout << endl;

}

Map* GameInitializer::choose_Map() {
	Map* m1=new Map();
	int choice;
	string fileName;
	cout << "What's kind of map you would like to play? \n1 -- Rectangular Shap\n2 -- L Shape\n3 -- Invalid Map" << endl;
	cin >> choice;
	while (true) {
		if (choice == 1) {
			cout << "reading Rectangular Shape map from mapFiles\\map5.json" << endl;
			fileName = "mapFiles\\map5.json";
			system("pause");
			system("cls");
			
			this->game_Show();
			// IF LOAD FALID ==> STOP SYSTEM !!!
			this->loadMap(fileName);

			// LOAD SUCCESSFULLY
			this->getCurrentMap()->validate();

			//// IF MAP INVALID ==> STOP SYSTEM !!!
			//if (this->getCurrentMap()->validate==false) {
			//	cout << "Map is not ValidateMap" << endl;
			//	system("pause");
			//	exit(0);
			//}

			// VALIDATE MAP
			
		    m1 = this->getCurrentMap();
			system("pause");
			system("cls");

			this->game_Show();
			cout << *m1;
			system("pause");
			system("cls");

			this->game_Show();
			this->printMapInRectangleShape(m1);
			system("pause");
			system("cls");

			break;

		}
		else if (choice == 2) {
			cout << "reading L Shape map from mapFiles\\map6.json" << endl;
			fileName = "mapFiles\\map6.json";
			system("pause");
			system("cls");

			this->game_Show();
			// IF LOAD FALID ==> STOP SYSTEM !!!
			this->loadMap(fileName);

			// LOAD SUCCESSFULLY
			this->getCurrentMap()->validate();

			//// IF MAP INVALID ==> STOP SYSTEM !!!
			//if (this->getCurrentMap()->validate==false) {
			//	cout << "Map is not ValidateMap" << endl;
			//	system("pause");
			//	exit(0);
			//}

			// VALIDATE MAP

			m1= this->getCurrentMap();
			system("pause");
			system("cls");
		

			this->game_Show();
			cout << *m1;
			system("pause");
			system("cls");

			this->game_Show();
			this->printMapInLShape(m1);
			system("pause");
			system("cls");

			break;
		}
		else if (choice == 3) {
			cout << "reading Invalid map from mapFiles\\map3.json" << endl;
			fileName = "mapFiles\\map3.json";
			//system("cls");
			
			// IF LOAD FALID ==> STOP SYSTEM !!!
			this->loadMap(fileName);

			// LOAD SUCCESSFULLY
			this->getCurrentMap()->validate();
			break;
		}
		else {
			cout << "Only 1, 2, 3 are permited! Please try again!\n";
			cout << "Which shape you would like to loded?\n1-- ***Rectangular Shape***\n2-- ***L Shape***\n3 -- Invalid Map" << endl;
			cin >> choice;
		}
	}

	return m1;


}





//initialize the player
vector<Player*>& GameInitializer::choose_Player() {

	int  choice =0 ;
	string color1;
	string color2;
	string name1;
	string name2;
	vector<Territory*> t1;
	vector<Territory*>t2;
	vector<Card*> c1;
	vector<Card*>c2;
	
	cout << "How many Player you would like to play with? \n1 -- two PLAYERS\n2 -- three PLAYERS\n3 -- four PLAYERS" << endl;
	cin >> choice;
	while (true) {
		if (choice==1) {
			
			system("cls");
			this->game_Show();
			cout << "Please insert first Player's name" << endl;
			cin >> name1;
			while (name1 == "") {
				cout << "Player's name can not be empty, please enter again" << endl;
				cin >> name1;
			}
			cout << "Please choose a color \n*****red*****\n*****yellow*****\n*****blue*****\n*****green*****" << endl;
			cin >> color1;
			while (true) {
				if ((color1 == "red") || (color1 == "yellow") || (color1 == "blue") || (color1 == "green")) 
					break;
				else {
					cout << "This color does not exist, please insert the color color!" << endl;
					cin >> color1; 
				}
			}
			

			Player *p1 = new Player(name1,10,0,t1,c1,(new Bidding()),color1);
			cout << "Please insert second Player's name" << endl;
			cin >> name2;
			while (name2 == ""||name2==name1) {
				if (name2 == "") {
					cout << "Player's name can not be empty, please insert again" << endl;
					cin >> name2;
				}
				else {
					cout << "Player's name can not be the same as the first player, Please insert again." << endl;
					cin >> name2;
				}
				
			}

			cout << "Please choose a color \n*****red*****\n*****yellow*****\n*****blue*****\n*****green*****" << endl;
			cin >> color2;
			cout << endl;
			while (true) {
				if ((color1 != color2) && (color2 == "red" || color2 == "yellow" || color2 == "blue" || color2 == "green"))
					break;
				else if(color1 == color2){
					cout << "Color can not be the same as the first player's color, Please choose again!" << endl;
					cin >> color2;
					cout << endl;
				}
				else{
					cout << "This color does not exist, please insert the color color!!" << endl;
					cin >> color2;
					cout << endl;
				}
				
			}
			
			Player *p2 = new Player(name2, 10, 0, t1, c1, (new Bidding()), color2);
		
			cout << "*****First Player*****"<<*p1<<"\n*****Second Player*****"<< *p2 << endl;

			this->players.push_back(p1);
			this->players.push_back(p2);

			cout<<"*****"<<p1->GetName()<< " and "<<p2->GetName()<<"***** \n*****welcome to the game , Hope you enjoy the Game!*****"<<endl;
			
			system("pause");

			break;
		}
		else if(choice==2) {

			cout << "We wil not try 3 players game, Only 2 players is allowed for Assignment. Please try again!\n";
			cout << "How many Player you would like to play with? \n1 -- two PLAYERS\n2 -- three PLAYERS\n3 -- four PLAYERS" << endl;
			cin >> choice;

		}
		else if (choice == 3) {

			cout << "We wil not try 4 players game, Only 2 players is allowed for Assignment. Please try again!\n";
			cout << "How many Player you would like to play with? \n1 -- two	PLAYERS\n2 -- three PLAYERS\n3 -- four PLAYERS" << endl;
			cin >> choice;

		}
		else {
			cout << "Invalid Number, please try again, \n1 -- 2	PLAYERS\n2 -- 3 PLAYERS\n3 -- four PLAYERS" << endl;
			cin >> choice;
		}

	}


	return this->players;

}








void GameInitializer::exitSystem() {
	cout << "~~~~~WELCOME BACK NEXT TIME *_* ~~~~~" << endl;
	system("pause");
	exit(0);
}

Map * GameInitializer::getCurrentMap() {
	try {
		return this->map;
	}
	catch(runtime_error){
		cout << "File is not falid" << endl;
	}
}

vector<string> GameInitializer::getGameMapFiles() {
	vector<string> maps;
	for (const auto & entry : fs::directory_iterator(mapFileFolder)) {
		std::cout << entry.path() << std::endl;
		maps.push_back(entry.path().string());
	}
	return maps;
}

void GameInitializer::loadMap(string mapFileName) {
	this->mapLoader = new MapLoader(mapFileName);
	if (this->mapLoader->readMapFile()) {
		this->map = this->mapLoader->getMap();
	}
	else {
		cout << "MAP INVALID TO LOAD...EXIT PROGRAM NOW\n";
		system("pause");
	}
}



void GameInitializer::addPlayer(string playerName) {
	vector<Card*> cards;
	Bidding* bid = new Bidding();
	Player* player = new Player(playerName, cards, bid);

}

string GameInitializer::getMapFileFolder() {
	return this->mapFileFolder;
}


//Rectangule Shape read from mapFiles\\map5.json
void GameInitializer::printMapInRectangleShape(Map* m1) {

	cout << "Rectuangule shape map Read from mapFiles\\map5.json..." << endl;
	cout << "\n*********************  MAP IN RECTANGULE SHAPE  ***************\n\n";
	for (int i = 0; i < m1->GetContinentCount(); i++) {
		 cout << " ~~~" << m1->continents[i]->GetName() << "~~~ " << "    ";
	
	}
	cout << "***************************************************************************************\n\n" << endl;
	for (int i = 0; i < m1->GetContinentCount(); i++) {
		if (i == 1) cout << " [ *" << m1->continents[i]->territorys[3]->GetName() << "* ] " << "____";
		else if (i == 3) cout << " [ *" << m1->continents[i]->territorys[3]->GetName() << "* ] " << "    ";
		else cout << " [ *" << m1->continents[i]->territorys[0]->GetName() << "* ] " << "    ";

	}
	cout << endl;

	for (int i = 0; i < m1->GetContinentCount(); i++) {
		if (i == 1) cout << " [ *" << m1->continents[i]->territorys[2]->GetName() << "* ] " << "    ";
		else if (i == 3) cout << " [ *" << m1->continents[i]->territorys[2]->GetName() << "* ] " << "    ";
		else cout << " [ *" << m1->continents[i]->territorys[1]->GetName() << "* ] " << "    ";

	}
	cout << endl;
	
	for (int i = 0; i < m1->GetContinentCount(); i++) {
		if (i == 1) cout << " [ *" << m1->continents[i]->territorys[1]->GetName() << "* ] " << "    ";
		else if (i == 3) cout << " [ *" << m1->continents[i]->territorys[1]->GetName() << "* ] " << "    ";
		else cout << " [ *" << m1->continents[i]->territorys[2]->GetName() << "* ] " << "    ";
	}
	cout << endl;
		cout << "\t|_____________" << " [ *" << m1->continents[1]->territorys[0]->GetName()<< "* ] " << "           |_______________";
	cout << "[ *" << m1->continents[3]->territorys[0]->GetName() << "* ] " << "    " << endl;
	cout << "\n\n***************************************************************************************\n\n" << endl;

}

void GameInitializer::printMapInLShape(Map* m1) {
	cout << "L shape map Read from mapFiles\\map6.json..." << endl;
	cout << "\n*********************  MAP IN L SHAPE  ***************\n\n";
	
	cout << "***************************************************************************************\n\n" << endl;
	for (int i = 0; i < 2; i++) {
		for (int j = 0; j < m1->continents[i]->getTerritoryCount(); j++) {
			cout << " [ *" << m1->continents[i]->territorys[j]->GetName() << "* ] " << endl;
		}
		cout << "\t|" << endl;
		cout << "\t|" << endl;
	}
	for (int i = 0; i < 3; i++) {
		cout << " [ *" << m1->continents[2]->territorys[i]->GetName() << "* ] " << "    ";
		cout << " [ *" << m1->continents[3]->territorys[3-i]->GetName() << "* ] " << "    \n";
	}
	cout << " [ *" << m1->continents[2]->territorys[3]->GetName() << "* ] " << "____";
	cout << " [ *" << m1->continents[3]->territorys[3]->GetName() << "* ] " << "    ";
	cout << "\n\n***************************************************************************************\n\n" << endl;

}
