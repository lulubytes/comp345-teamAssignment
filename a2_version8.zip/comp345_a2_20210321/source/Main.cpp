#include "MapDriver.cpp"
#include "MapLoaderDriver.cpp"
#include "PlayerDriver.cpp"
#include "CardsDriver.cpp"
#include "BiddingDriver.cpp"
#include "GameInitializerDriver.cpp"
#include "GameMainDriver.cpp"
#include "GameStartupDriver.cpp"


using namespace std;
// for vs code to run the code
//  g++ -std=c++17 *.cpp && ./a.out 


static vector<Player*> vPlayers;
static Map *map;
static int Pool = 0;



int main() {

	// Drivers for A1
	//(new MapDriver())->run();
	//(new MapLoaderDriver())->run();
	//(new CardsDriver())->run();
	//(new PlayerDriver())->run();
	//(new BiddingDriver())->run();


	//Test Drivers for A2
	//(new GameInitializerDriver())->run();     //test for Part one
	//(new GameStartupDriver())->run();			//test for part two
	//(new GameMainDriver())->run();			//test for part three to Part six







	//Run the Entire Game
	GameInitializer* gameInitializer = new GameInitializer();
	int choice = 0;
	while (true) {
		gameInitializer->show_Menu();
		cout << "\nPlease Insert your Choice!" << endl;
		cin >> choice;  //receive the choice from user
		switch (choice) {
		case 1:
			system("cls");
			gameInitializer->game_Show();
			map = gameInitializer->choose_Map();//1.CHOSE MAP 

			break;
		case 2:
			system("cls");
			gameInitializer->game_Show();
			vPlayers = gameInitializer->choose_Player();//2. get Players

			Pool = gameInitializer->pool;
			cout << Pool << endl;

			system("pause");
			break;
		case 3:
			system("cls");
			gameInitializer->game_Show();
			gameInitializer->exitSystem();// 3. EXIT THE GAME 
			break;
		default:
			cout << "Invalid Insert! Please insert the correct number." << endl;
			system("pause");
			system("cls"); //clean the console
			break;
		}
	}


	system("pause");
	return 0;
}









//#include <iostream>
//#include <string>
//#include "..\header\Cards.h"
//#include "..\header\Player.h"
//#include <filesystem>
//#include <algorithm>
//#include<string>
//#include <stdio.h>
//#include <random>
//using namespace std;
//
//
//
////*************    Card   **************************
//
//Card::Card() {};
//Card :: ~Card() {};
//
//Card::Card(string good, string action, string ability, string andor){
//	this->good = good;
//	this->action[0] = action;
//	this->ability = ability;
//	this->AndOr = andor;
//}
//
//Card ::Card(string good, string firstAction, string secondAction, string ability, string andor){
//	this->good = good;
//	this->action[0] = firstAction;
//	this->action[1] = secondAction;
//	this->ability = ability;
//	this->AndOr = andor;
//}
//
////Copy constructor
//Card::Card(const Card& c)
//{
//	this->good = c.good;
//	this->action[0] = c.action[0];
//	this->action[1] = c.action[1];
//	this->ability = c.ability;
//	this->AndOr = c.AndOr;
//}
//
//string Card::getGood(){
//	return this->good;
//}
//
//string Card::getAction1(){
//	return this-> action[0];
//}
//
//string Card::getAction2(){
//	return this->action[1];
//}
//
//string Card::getAbility(){
//	return this->ability;
//}
////print Card information
//void Card::printCard()
//{
//	cout << "Card Information: \n" << endl;
//	cout << "Good: " << this->good << endl;
//	cout << "Action: " << this->action[0] << endl;
//	if (AndOr == "and") cout << "AND" << endl;
//	if (AndOr == "or")cout << "OR" << endl;
//	cout << "Action: " << action[1];
//	cout << "Ability: " << this->ability << endl;
//
//}
//// overload operator <<
//ostream& operator<<(ostream& out, const Card& card) {
//	cout<< "Good: " << card.good <<"Ability"<<card.ability<< "Action1: " << card.action[0] << "Action2 "<< card.action[1] << endl;
//	return out;
//}
//
//// assignment operator
//Card& Card::operator=(const Card& card)
//{
//	if (&card == this) {
//		return *this;
//	}
//	else {
//		this->good = card.good;
//		this->action[0] = card.action[0];
//		this->action[1] = card.action[1];
//		this->ability = card.ability;
//		this->AndOr = card.AndOr;
//		return *this;
//	}
//		
//	
//}
//
//
////*************    Deck   **************************
//
//void Deck::generateDeck()
//{
//	//each card with good and 2 or 1 action
//	cards[0] = Card(good.PIXIE, "", "Move4", ability.P1A);
//	cards[1] = Card(good.STRONGHOLD, "", "BuildCity", ability.P1VPD);
//	cards[2] = Card(good.Phoenix, "", "Move5", ability.FYLING);
//	cards[3] = Card(good.Spirit, "", "Add4", ability.THRE);
//	cards[4] = Card(good.WOODS, "and", "BuildCity", "Add1", ability.P1A);
//	cards[5] = Card(good.SAGE, "", "Move3", ability.P1VP);
//	cards[6] = Card(good.CB, "", "Move6", ability.TE);
//	cards[7] = Card(good.GAR, "", "Move5", ability.FYLING);
//	cards[8] = Card(good.KING, "or", "Add3", "Move4", ability.OE);
//	cards[9] = Card(good.MAUSOLEUM, "", "BuildCity", ability.P1M);
//	cards[10] = Card(good.TOWER, "", "BuildCity", ability.P1VPF);
//	cards[11] = Card(good.DRAGON, "and", "Add3", "Destory", ability.FYLING);
//	cards[12] = Card(good.GIANT, "and", "Add3", "Destory", ability.ITA);
//	cards[13] = Card(good.EYE, "", "Add4", ability.FYLING);
//	cards[14] = Card(good.GOB, "", "Move4", ability.OE);
//
//	cards[15] = Card(good.OGRE, "", "Move2", ability.P1P3);
//	cards[16] = Card(good.LAKE, "or", "Add2", "Move3", ability.P1VPF);
//	cards[16] = Card(good.ELF, "or", "Add3", "Move2", ability.P1A);
//	cards[18] = Card(good.GNOME, "", "Move2", ability.THRE);
//	cards[19] = Card(good.TOWN, "", "BuildCity", ability.P1M);
//	cards[20] = Card(good.GRAVEYARD, "", "Add2", ability.P1VPC);
//	cards[21] = Card(good.HILLS, "", "Add3", ability.P5VP3);
//	cards[22] = Card(good.KNIGHT, "and", "Add4", "Destory", ability.P1M);
//	cards[23] = Card(good.UNICORN, "and", "Move4", "Add1", ability.P1M);
//	cards[24] = Card(good.HYDRA, "and", "Move4", "Destory", ability.P1A);
//	cards[25] = Card(good.VILLAGE, "", "BuildCity", ability.P1A);
//	cards[26] = Card(good.WIZARD, "and", "Add4", "Destory", ability.P1VPN);
//
//	//3 Player cards
//	if (Deck::number >= 3) {
//		cards[26] = Card(good.SPHINX, "or", "Add3", "Move4", ability.FYLING);
//		cards[28] = Card(good.MANTI, "and", "Add4", "Destory", ability.P1M);
//		cards[29] = Card(good.TEMPLE, "", "Move3", ability.P1AR);
//		cards[30] = Card(good.DWARF, "and", "Add2", "Destory", ability.P3VP2);
//		cards[31] = Card(good.TREASURY, "", "Move3", ability.OA2C);
//	}
//	//4 Player cards
//	if (Deck::number >= 4) {
//		cards[32] = Card(good.CASTLE, "or", "Add4", "BuildCity", ability.OE);
//		cards[33] = Card(good.CASTLE2, "and", "Move3", "BuildCity", ability.OE);
//	}
//}
//
//Deck::Deck()
//{
//	this->topCard = &cards[0];
//	this->number = 2;
//}
//
////CopyConstructor
//Deck::Deck(const Deck& d)
//{
//	this->topCard = new Card(*d.topCard);
//	for (int i = 0; i < 34; i++){
//		this->cards[i] = d.cards[i];
//	}
//	this->number = d.number;
//}
//
//Deck::Deck(int numPlay) {
//	topCard = &cards[0];
//	number = numPlay;
//}
//
////Deconstructor
//Deck ::~Deck()
//{
//	if (this->topCard != NULL) {
//		delete topCard;
//	}
//	this->topCard = NULL;
//	
//}
////Displays all deck
//void Deck::printDeck()
//{
//	for (int i = 0; i < 34; i++)
//	{
//		cout << "Cards Information: \n" << "Card number: " << i + 1 << " : ";
//		cards[i].printCard();
//		cout << endl;
//	}
//}
//int Deck::getNumCards() {
//	if (number == 2) return 26;
//	if (number == 3) return 32;
//	if (number == 4) return 34;
//}
//
//int Deck::myRandomGenerator(int j) {
//	return rand() % j;
//}
//
//void Deck::shuffleDeck() {
//	srand(time(0));
//	//random_shuffle(&cards[0], &cards[getNumCards()], myRandomGenerator);
//}
//
//
//
//
////draw card 
//Card* Deck::draw()
//{
//	Card* card = topCard;
//	topCard++;
//	return card;
//}
//
//// toString Deck
//ostream& operator<<(ostream& strm, const Deck& deck)
//{
//	return strm << "We have 34 cards totally";
//}
//// Assignment operator.
//Deck& Deck::operator=(const Deck& anotherDeck)
//{
//	if (&anotherDeck == this)
//		return *this;
//	for (int i = 0; i < 34; i++)
//	{
//		cards[i] = anotherDeck.cards[i];
//	}
//	topCard = &cards[0];
//	return *this;
//}
//
//
////********************  hand    **********************************
//
//Hand::Hand() {
//
//}
//
//Hand::Hand(Deck* deck){
//	
//	//draw 6 cards from deck
//	for (int i = 0; i < 6; i++)
//	{
//		this->cards[i] = deck->draw();
//	}
//}
//
////CopyConstructor
//Hand::Hand(const Hand& h)
//{
//	deck = new Deck(*(h.deck));
//	for (int i = 0; i < 6; i++)
//	{
//		cards[i] = deck->draw();
//	}
//}
//
//Hand::~Hand() {
//	/*if (this->deck != NULL) {
//		delete deck;
//		
//	}
//	deck = NULL;
//	for (int i = 0; i < 6; i++) {
//		if (this->cards != NULL) {
//			delete cards[i];
//			
//		}
//		cards[i] = NULL;
//	}
//	delete cards;*/
//	
//}
//
////Returns the cost of a card 
//int Hand::getCost(int index)
//{
//	if (index == 0)
//		return 0;
//	else if (index == 1)
//		return 1;
//	else if (index == 2)
//		return 1;
//	else if (index == 3)
//		return 2;
//	else if (index == 4)
//		return 2;
//	else if (index == 5)
//		return 3;
//	else
//		return -1;
//}
//
////Shifts cards left with the index number
//void Hand::shiftCards(int index)
//{
//	for (int i = index; i < 6; i++)
//	{
//		cards[i] = cards[i + 1];
//	}
//}
//
////choose card and get the cost
//
//Card* Hand::exchange(int cardIndex) {
//
//	int cost = getCost(cardIndex);
//
//	Card* pickedCard = (cards[cardIndex]);
//
//	shiftCards(cardIndex);
//
//	cards[5] = deck->draw();
//
//	return pickedCard;
//}
//
////print the content of hand
//void Hand::printHand()
//{
//	
//	for (int i = 0; i < 6; i++)
//	{
//		cout << "This is the information of hand cards: " <<endl;
//		cout << "Good: " << this->cards[i]->getGood();
//		cout << "Action 1: " << this->cards[i]->getAction1() ;
//		cout << "Action 2: " << this->cards[i]->getAction2() ;
//	}
//}
//
//// operator << overload 
//ostream& operator<<(ostream& out, const Hand& hand)
//{
//	cout << "These are 6 cards in hand";
//		for (int i = 0; i < 6; i++)
//		{
//			cout << "This is the information of hand cards: " << endl;
//			cout << "Good: " <<hand.cards[i]->getGood();
//			cout << "Action 1: " << hand.cards[i]->getAction1();
//			cout << "Action 2: " << hand.cards[i]->getAction2();
//		}
//
//	return out; 
//}
//
//Hand& Hand::operator=(const Hand& hand)
//{
//	if (&hand == this)
//		return *this;
//	if (hand.deck)
//	{
//		deck = new Deck(*hand.deck);
//		for (int i = 0; i < 6; i++)
//		{
//			cards[i] = deck->draw();
//		}
//	}
//
//	return *this;
//}