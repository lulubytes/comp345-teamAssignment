#include <iostream>
#include <string>
#include "..\header\Cards.h"
#include "..\header\Player.h"
using namespace std;


Card::Card() 
{
	name = "";
	good = "";
	action = "";
}

Card::~Card()
{}

Card::Card(string name, string good, string action) 
{
	name = name;
	good = good;
	action = action;
}


Card::Card(const Card& other) 
{
	this->name = other.name;
	this->good = other.good;
	this->action = other.action;

}

Card& Card::operator=(const Card& other) 
{
	this->name = other.name;
	this->good = other.good;
	this->action = other.action;
	return *this;
}


ostream& operator<<(ostream& output, const Card& other) 
{
	return output << "Card Name: " << other.name << " Goods: " << other.good << " Action: " << other.action  << endl;
}

Deck::Deck() 
{

}

Deck::Deck(const Deck& other) 
{
	for (int i = 0; i < other.cards.size(); i++) 
	{
		Card* card = new Card(*other.cards[i]);
		this->cards.push_back(card);
	}

}

Deck& Deck::operator=(const Deck& other) 
{
	for (int i = 0; i < other.cards.size(); i++) 
	{
		Card* card = new Card(*other.cards[i]);
		this->cards.push_back(card);
	}
	return *this;
}

Deck::~Deck() 
{
	for (int i = 0; i < cards.size(); i++) 
	{
		delete cards[i];
		cards[i] = nullptr;
	}
}


ostream& operator<<(ostream& output, const Deck& other) 
{
	output << "Deck Cards : ";
	output << other.cards.size();
	output << endl;
	for (int i = 0; i < other.cards.size(); i++) 
	{
		output << i + 1;
		output << ": " << *(other.cards[i]);
	}
	output << endl;
	return output;
}

Card* Deck::draw() 
{
	Card* tempcard = new Card(*(this->cards.front()));
	delete this->cards.front();
	this->cards.front() = nullptr;
	this->cards.erase(this->cards.begin());
	return tempcard;
}


vector<Card*> Deck::GetDeck() 
{
	return cards;
}


void Deck::SetDeck(Card* other) 
{
	this->cards.push_back(other);
}

Hand::Hand() 
{
}

Hand::Hand(const Hand& other) 
{
	for (int i = 0; i < other.cards.size(); i++) 
	{
		Card* card = new Card(*other.cards[i]);
		this->cards.push_back(card);
	}

}

Hand& Hand::operator=(const Hand& other) 
{

	for (int i = 0; i < other.cards.size(); i++) 
	{
		Card* card = new Card(*other.cards[i]);
		this->cards.push_back(card);
	}
	return *this;
}

Hand::~Hand() 
{
	for (int i = 0; i < cards.size(); i++) 
	{
		delete cards[i];
		cards[i] = nullptr;
	}
}

ostream& operator<<(ostream& output, const Hand& other) 
{
	output << "Hand Card: ";
	output << endl;
	for (int i = 0; i < other.cards.size(); i++) 
	{
		output << i + 1;
		output << ": " << *(other.cards[i]);
	}
	output << endl;
	return output;
}

void Hand::SetHand(Card* other) 
{
	this->cards.push_back(other);
}

void Hand::exchange(int index, Player* player) 
{
	int cost;
	switch (index)
	{
	case 1:
		cost = 0;
		break;
	case 2:
	case 3:
		cost = 1;
		break;
	case 4:
	case 5:
		cost = 2;
		break;
	case 6:
		cost = 3;
		break;
	default:
		break;
	}

	if (player->GetCoin() < cost) 
	{
		cout << player->GetName() << ": You do not have enough coin pay for card cost" << endl;
		return;
	}


	player->SetCoin(cost);
	Card* card = new Card(*cards[index - 1]);
	player->GetHandCard().push_back(card);
	cout << "\n" << player->GetName() << " has select " << *card << endl;
	Card* hand = cards[index - 1];
	cards.erase(this->cards.begin() + (index - 1));
	delete hand;
	hand = nullptr;
	delete card;
	card = nullptr;

}

vector<Card*> Hand::GetHand() 
{
	return cards;
}
