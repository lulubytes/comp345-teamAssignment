#include "..\header\GameInitializer.h"

using namespace std;

class GameInitializerDriver
{

public:
    void run()
    {
        GameInitializer *gameInitializer = new GameInitializer();
        cout << "GameInitiazlider started" << endl;
        cout << "reading map from " << gameInitializer->getMapFileFolder() << endl;

        cout << "Read maps"<<endl;
        vector<string> maps=gameInitializer->getGameMapFiles();

        for(int i=0;i<maps.size();i++){
            gameInitializer->loadMap(maps[i]);	
        }
    }
};
