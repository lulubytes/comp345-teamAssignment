#include "..\header\GameInitializer.h"
#include <filesystem>

namespace fs = std::experimental::filesystem;

GameInitializer::GameInitializer(){
    this->map=nullptr;
    this->mapLoader=nullptr;

}

//Map* GameInitializer::getCurrentMap() {
//	return this->map;
//}

vector<string> GameInitializer::getGameMapFiles(){
    vector<string> maps;
    for (const auto & entry : fs::directory_iterator(mapFileFolder)){
        std::cout << entry.path() << std::endl;
        maps.push_back(entry.path().string());
    }
    return maps;
}

void GameInitializer::loadMap(string mapFileName){
    this->mapLoader=new MapLoader(mapFileName);
    if(this->mapLoader->readMapFile()){
        this->map=this->mapLoader->getMap();
    }else{
        cout<< "Map Invild";
    }
}

void GameInitializer::addPlayer(string playerName){
    vector<Card*> cards;
    Bidding* bid=new Bidding();
    Player* player=new Player(playerName,cards,bid);
    
}

string GameInitializer::getMapFileFolder(){
    return this->mapFileFolder;
}