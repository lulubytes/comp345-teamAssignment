#include "MapDriver.cpp"
#include "MapLoaderDriver.cpp"
#include "PlayerDriver.cpp"
#include "CardsDriver.cpp"
#include "BiddingDriver.cpp"
#include "GameInitializerDriver.cpp"
#include "GameMainDriver.cpp"
#include "GameStartupDriver.cpp"

using namespace std;

//  g++ -std=c++17 *.cpp && ./a.out 

int main(){
    
    (new MapDriver()) -> run();
    (new MapLoaderDriver()) -> run();
    (new CardsDriver()) -> run();
    (new PlayerDriver()) -> run();
    (new BiddingDriver()) -> run();
    (new GameInitializerDriver())->run();
    (new GameStartupDriver())->run();
    (new GameMainDriver())->run();

	system("pause");
}