#include "..\header\GameMain.h"
using namespace std;

GameMain::GameMain(){}

