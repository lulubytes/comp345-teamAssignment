

class GameStartup{
private:

public:
    GameStartup();

};