#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <stdio.h>

using namespace std;

class Player;

class Card
{
public:
	Card();
	Card(string name, string good, string action);
	Card(const Card& other);
	Card& operator = (const Card& other);
	~Card();
	friend ostream& operator<<(ostream& output, const Card& other);
private:
	string name;
	string good;
	string action;
};

class Deck 
{
public:
	Deck();
	Deck(const Deck& other);
	Deck& operator = (const Deck& other);
	~Deck();
	friend ostream& operator<<(ostream& output, const Deck& other);
	Card* draw();
	vector<Card*> GetDeck();
	void SetDeck(Card* other);
private:
	vector<Card*> cards;
};

class Hand 
{

public:
	Hand();
	Hand(const Hand& other);
	Hand& operator = (const Hand& other);
	~Hand();
	friend ostream& operator<<(ostream& output, const Hand& other);
	void exchange(int index, Player* player);
	vector<Card*> GetHand();
	void SetHand(Card* other);
private:
	vector<Card*> cards;
};