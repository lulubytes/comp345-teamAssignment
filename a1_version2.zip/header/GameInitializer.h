#include "Map.h"
#include "MapLoader.h"
#include "Player.h"
#include "Cards.h"
#include "Bidding.h"
#include <vector>

using namespace std;

class GameInitializer{
private:
    const string mapFileFolder="../mapFiles";
    MapLoader* mapLoader;
    Map* map;
    vector<Player*> players;

public:
    GameInitializer();
    vector<string> getGameMapFiles();
	//Map* getCurrentMap();
    void loadMap(string mapFileName);
    void addPlayer(string playerName);
    string getMapFileFolder();
};